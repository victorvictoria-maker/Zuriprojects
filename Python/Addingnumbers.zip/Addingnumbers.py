varA = 5;
varB = 6;
varC = varA + varB;
print(varC);
